// Side Contents
var list = `<ul>`;
for(let i=0; i<16; i++){
    const lists = ["About You", "Properties", "Rent", "Services", "About Us", "Properties",  "Settings", "Log Out"]
    list += `<li id="trgt">${lists[i%8]}</li>`;
}
list += `</ul>`;
document.querySelector("#side-content").innerHTML = list;


//Sliding Contents
var pic = "", slide = "";
for(let i=1; i<=5; i++) pic += `<img src="Houses/home-${i}.jpg" alt="Home-${i}">`;
for(let j=1; j<=2; j++) slide += `<div class="images">${pic}</div>`;
document.querySelector(".latest").innerHTML = slide;


//Properties
var info = "";
for(let i=1; i<=12; i++){
    const rent = ["৫,৫০০", "৯০০০", "৮০০০", "৩৫০০", "৪২০০", "৩৮০০", "৬০০০", "৫০০০", "১০০০০", "৪৫০০"];
    const location = ["সাভার","আশুলিয়া","দত্তপাড়া","খাগান বাজার","চারাবাগ","খেজুরবাগান","সাধুপাড়া","আকরাইন","চানগাও","উত্তরা"];
    info += `<div class="box house-info">
                <a href="details.html"><img id="myHouse${i} onclick = showDetails${i}() "src="Houses/home-${i}.jpg" alt="home-${i} id="Img"></a>
                <h3>Location : ${location[i%10]}</h3>
                <h5>Rent : ${rent[i%10]}&#2547;</h5>
                <a href="details.html"><button id="myHouse${i} onclick = showDetails${i}()">View Details</button></a>
                <a href="rent.html"><button>Rent</button></a>
            </div>`;
    
}
document.querySelector(".content").innerHTML = info;

function nxt(){
    var info = "";
    for(let i=13; i<=24; i++){
        const rent = ["৫,৫০০", "৯০০০", "৮০০০", "৩৫০০", "৪২০০", "৩৮০০", "৬০০০", "৫০০০", "১০০০০", "৪৫০০"];
        const location = ["সাভার","আশুলিয়া","দত্তপাড়া","খাগান বাজার","চারাবাগ","খেজুরবাগান","সাধুপাড়া","আকরাইন","চানগাও","উত্তরা"];
        info += `<div class="box house-info">
                    <a href="details.html"><img id="myHouse${i} onclick = showDetails${i}() "src="Houses/home-${i}.jpg" alt="home-${i} id="Img"></a>
                    <h3>Location : ${location[i%10]}</h3>
                    <h5>Rent : ${rent[i%10]}&#2547;</h5>
                    <a href="details.html"><button id="myHouse${i} onclick = showDetails${i}()">View Details</button></a>
                    <a href="rent.html"><button>Rent</button></a>
                </div>`;
        
    }
    document.querySelector(".content").innerHTML = info;
}


function bck(){
    var info = "";
    for(let i=1; i<=12; i++){
        const rent = ["৫,৫০০", "৯০০০", "৮০০০", "৩৫০০", "৪২০০", "৩৮০০", "৬০০০", "৫০০০", "১০০০০", "৪৫০০"];
        const location = ["সাভার","আশুলিয়া","দত্তপাড়া","খাগান বাজার","চারাবাগ","খেজুরবাগান","সাধুপাড়া","আকরাইন","চানগাও","উত্তরা"];
        info += `<div class="box house-info">
                    <a href="details.html"><img id="myHouse${i} onclick = showDetails${i}() "src="Houses/home-${i}.jpg" alt="home-${i} id="Img"></a>
                    <h3>Location : ${location[i%10]}</h3>
                    <h5>Rent : ${rent[i%10]}&#2547;</h5>
                    <a href="details.html"><button id="myHouse${i} onclick = showDetails${i}()">View Details</button></a>
                    <a href="rent.html"><button>Rent</button></a>
                </div>`;
        
    }
    document.querySelector(".content").innerHTML = info;
}


function clear_filter(){
    document.getElementById('.flt1').value = "";
}