

function ChangeImage1(){
    var image = document.getElementById('mainImage')
    var clicked_image = document.getElementById('myImage1')

    if (image.src.match(clicked_image.src)) {
        image.src = image.src;
      } else {
        image.src = clicked_image.src;
      }
}

function ChangeImage2(){
    var image = document.getElementById('mainImage')
    var clicked_image = document.getElementById('myImage2')

    if (image.src.match(clicked_image.src)) {
        image.src = image.src;
      } else {
        image.src = clicked_image.src;
      }
}

function ChangeImage3(){
    var image = document.getElementById('mainImage')
    var clicked_image = document.getElementById('myImage3')

    if (image.src.match(clicked_image.src)) {
        image.src = image.src;
      } else {
        image.src = clicked_image.src;
      }
}

function ChangeImage4(){
    var image = document.getElementById('mainImage')
    var clicked_image = document.getElementById('myImage4')

    if (image.src.match(clicked_image.src)) {
        image.src = image.src;
      } else {
        image.src = clicked_image.src;
      }
}

function ChangeImage5(){
    var image = document.getElementById('mainImage')
    var clicked_image = document.getElementById('myImage5')

    if (image.src.match(clicked_image.src)) {
        image.src = image.src;
      } else {
        image.src = clicked_image.src;
      }
}