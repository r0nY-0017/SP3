var info = "";
var t=5;
while(t--){
    for(let i=1; i<=24; i++){
        const rent = ["5,500", "9,500", "7,000", "3,500", "8,000", "4,000", "6,000", "5,000", "10,000", "4,500"];
        const location = ["Savar", "Ashulia", "Dattapara", "Khagan","Charabag",
                          "Uttara", "Mirpur", "Akrain", "Changao", "Nabinagar"];
        info += `<div class="box house-info">
                    <a href="details.html"><img src="Houses/home-${i}.jpg" alt="home-${i} id="Img"></a>
                    <h3>Location : ${location[i%10]}</h3>
                    <h5>Rent : ${rent[i%10]}&#2547;</h5>
                    <a href="details.html"><button id="btn">View Details</button></a>
                    <a href="rent.html"><button id="btn">Rent</button></a>
                </div>`;

    }
}
document.querySelector(".content").innerHTML = info;